//======================================================================
//========  			Define Data Type         	========   
//======================================================================
#define uchar unsigned char
#define uint unsigned int
#define ulong unsigned long

